$(document).ready(function(){
    $(".heromain-back .left-details .portion input[type='radio']").click(function(){
        $(".heromain-back .custom-buton a.disabled").addClass("enabled"); 
    });
	
});


$(document).ready(function(){
    $("#filter-menu").click(function(){
        $(".filter-back").addClass("menu-filter");
		$(".overlay").addClass("in"); 
    });
	$(".overlay").click(function(){
        $(".filter-back").removeClass("menu-filter");
		$(".overlay").removeClass("in"); 
    });
	
});
$(document).ready(function(){
    $("#headermenu").click(function(){
        $(".header-menu").addClass("in");
		$(".overlay").addClass("in"); 
    });
	$(".overlay").click(function(){
        $(".header-menu").removeClass("in");
		$(".overlay").removeClass("in"); 
    });
	
});

$(document).ready(function(){
    $("#autocomplete").click(function(){
        $(".auto-complete").addClass("visible"); 
    });
	
});
$(document).ready(function(){
    $("#autocomplete").click(function(){
        $(".auto-complete").addClass("visible"); 
    });
	
});
$(document).ready(function(){
    $("#slide-log").click(function(){
        $(".log-in-dropdownback").slideToggle("fast");
    });
});
$(document).ready(function(){
    $("#open-tag").click(function(){
        $("#tag-open").slideToggle("fast");
    });
});

$('.login-register-back .form-sli:first-child').fadeIn('slow');
    
    $('.login-register-back #right-text').on('click', function () {
        var parent_fieldset = $(this).parents('.form-sli');
        var next_step = true;
        if (next_step) {
            parent_fieldset.fadeOut(400, function () {
                $(this).next().fadeIn();
            });
        }

    });
    
	$('.login-register-back #right-text-return').on('click', function () {
        $(this).parents('.form-sli').fadeOut(400, function () {
            $(this).prev().fadeIn();
        });
    });


    
	
	
	
$('.quote-res .port-sli:first-child').fadeIn('slow');
    
    $('.quote-res .btn-next').on('click', function () {
        var parent_fieldset = $(this).parents('.port-sli');
        var next_step = true;
        if (next_step) {
            parent_fieldset.fadeOut(400, function () {
                $(this).next().fadeIn();
            });
        }

    });
    
    $('.quote-res .btn-prev').on('click', function () {
        $(this).parents('.port-sli').fadeOut(400, function () {
            $(this).prev().fadeIn();
        });
    });
	
	
$(function() {
	  $('a.click[href*=#]:not([href=#])').click(function() {
	    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {

	      var target = $(this.hash);
	      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
	      if (target.length) {
	        $('html,body').animate({
	          scrollTop: target.offset().top
	        }, 1000);
	        return false;
	      }
	    }
	  });
	});

$(document).ready(function() {
	
	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content
	
	//On Click Event
	$("ul.tabs li").click(function() {
	
		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content
	
		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});
	
});

function myFunction() {
  var copyText = document.getElementById("copy-url");
  copyText.select();
  document.execCommand("copy");
  
  var tooltip = document.getElementById("myTooltip");
  tooltip.innerHTML = "Copied";
}

function outFunc() {
  var tooltip = document.getElementById("myTooltip");
  tooltip.innerHTML = "Copy to clipboard";
}


	 