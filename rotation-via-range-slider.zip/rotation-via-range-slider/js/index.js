var $rangeSlider = $('.range-slider'),
    $card = $('.card');

$rangeSlider.on("input", function() {
  inputValue = $rangeSlider.val();
  TweenMax.to($card, .3, {
    rotationX:inputValue/100, 
    rotationY:inputValue, 
    ease:Power2.easeOut});
  console.log('inputValue', inputValue);
});