//$("#click").click(function(){
  //  $("#hide").hide();
//});
jQuery(document).ready(function(){
   jQuery("#click").click(function(){
    jQuery("#hide").addClass("add-panel");
    jQuery("#hide").removeClass("add-panel2");
   }); 
   jQuery("#click2").click(function(){
     jQuery("#hide").removeClass("add-panel");
     jQuery("#hide").addClass("add-panel2");       
    }); 
});
